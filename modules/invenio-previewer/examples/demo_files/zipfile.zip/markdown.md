# Welcome to invenio-previewer

## It can display several formats of files

- markdown.md
- csvfile.csv
- zipfile.zip,
- jsonfile.json
- xmlfile.xml
- notebook.ipynb
- jpgfile.jpg
- pngfile.png
